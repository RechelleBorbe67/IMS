import random
from faker import Faker
import mysql.connector
from datetime import datetime, timedelta

# Initialize Faker
fake = Faker()

# Database connection
db = mysql.connector.connect(
    host="127.0.0.1", 
    user="root", 
    password="1234", 
    database="inventorydb" 
)
cursor = db.cursor()

# Generate sample data
def generate_categories(num_categories):
    categories = []
    for i in range(1, num_categories + 1):
        category_name = f"Category {i}"  # Ensure unique category names
        description = fake.text(max_nb_chars=200)
        categories.append((category_name, description))
    return categories

def generate_discounts(num_discounts):
    discounts = []
    for i in range(1, num_discounts + 1):
        discount_name = f"Discount {i}"
        product_id = random.randint(1, 100)  # Assuming 100 products exist
        discount_percentage = round(random.uniform(1, 50), 2)  # Between 1% and 50%
        start_date = fake.date_time_this_year()
        end_date = start_date + timedelta(days=random.randint(1, 30))  # End date is after start date
        is_active = random.choice([0, 1])  # Active or inactive
        discounts.append((product_id, discount_name, discount_percentage, start_date, end_date, is_active))
    return discounts

def generate_suppliers(num_suppliers):
    suppliers = []
    for i in range(1, num_suppliers + 1):
        name = fake.company()
        contact = fake.name()
        email = fake.email()
        phone = fake.msisdn()[:20]  # Truncate phone number to 20 characters
        address = fake.address()
        city = fake.city()
        country = fake.country()[:50]  # Truncate country to 50 characters
        postal_code = fake.postcode()
        suppliers.append((name, contact, email, phone, address, city, country, postal_code))
    return suppliers

def generate_users(num_users):
    users = []
    generated_usernames = set()  # Track unique usernames to avoid duplicates
    generated_emails = set()  # Track unique emails to avoid duplicates
    for i in range(1, num_users + 1):
        while True:
            username = fake.user_name()
            if username not in generated_usernames:  # Ensure unique username
                generated_usernames.add(username)
                break
        while True:
            email = fake.email()
            if email not in generated_emails:  # Ensure unique email
                generated_emails.add(email)
                break
        password = fake.password(length=10)  # Generate a random password
        role = random.choice(['admin', 'manager', 'staff'])  # Randomly assign a role
        created_at = fake.date_time_this_year()
        users.append((username, password, email, role, created_at))
    return users

# Insert data into the database
def insert_data(table, data, query):
    try:
        cursor.executemany(query, data)
        db.commit()
        print(f"Inserted {len(data)} records into {table}")
    except mysql.connector.Error as err:
        print(f"Error inserting into {table}: {err}")

# Main function
def main():
    # Test the database connection
    try:
        cursor.execute("SELECT DATABASE();")
        current_db = cursor.fetchone()
        print(f"Connected to database: {current_db[0]}")
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return

    # Generate and insert categories
    print("Generating categories...")
    categories = generate_categories(100000)  # Generate 100,000 categories
    category_query = """
        INSERT IGNORE INTO Categories (category_name, description)
        VALUES (%s, %s)
    """
    insert_data("Categories", categories, category_query)

    # Generate and insert discounts
    print("Generating discounts...")
    discounts = generate_discounts(100000)  # Generate 100,000 discounts
    discount_query = """
        INSERT IGNORE INTO Discounts (product_id, discount_name, discount_percentage, start_date, end_date, is_active)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    insert_data("Discounts", discounts, discount_query)

    # Generate and insert suppliers
    print("Generating suppliers...")
    suppliers = generate_suppliers(100000)  # Generate 100,000 suppliers
    supplier_query = """
        INSERT IGNORE INTO Suppliers (name, contact, email, phone, address, city, country, postal_code)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    insert_data("Suppliers", suppliers, supplier_query)

    # Generate and insert users
    print("Generating users...")
    users = generate_users(100000)  # Generate 100,000 users
    user_query = """
        INSERT IGNORE INTO Users (username, password, email, role, created_at)
        VALUES (%s, %s, %s, %s, %s)
    """
    insert_data("Users", users, user_query)

if __name__ == "__main__":
    main()