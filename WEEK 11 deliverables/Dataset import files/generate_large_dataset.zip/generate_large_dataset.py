import random
from faker import Faker
import mysql.connector
import json
from datetime import datetime, timedelta

# Initialize Faker
fake = Faker()

# Database connection
db = mysql.connector.connect(
    host="127.0.0.1", 
    user="root", 
    password="1234", 
    database="inventorydb" 
)
cursor = db.cursor()

# Generate sample data
def generate_discounts(num_discounts):
    discounts = []
    for i in range(1, num_discounts + 1):
        discount_name = f"Discount {i}"
        product_id = random.randint(1, 100)  # Assuming 100 products exist
        discount_percentage = round(random.uniform(1, 50), 2)  # Between 1% and 50%
        start_date = fake.date_time_this_year()
        end_date = start_date + timedelta(days=random.randint(1, 30))  # End date is after start date
        is_active = random.choice([0, 1])  # Active or inactive
        discounts.append((product_id, discount_name, discount_percentage, start_date, end_date, is_active))
    return discounts

def generate_order_items(num_items):
    order_items = []
    cursor.execute("SELECT order_id FROM Orders")  # Fetch existing order IDs
    order_ids = [row[0] for row in cursor.fetchall()]
    cursor.execute("SELECT product_id FROM Products")  # Fetch existing product IDs
    product_ids = [row[0] for row in cursor.fetchall()]

    for i in range(1, num_items + 1):
        order_id = random.choice(order_ids)  # Use a valid order_id
        product_id = random.choice(product_ids)  # Use a valid product_id
        quantity = random.randint(1, 10)
        price = round(random.uniform(10, 1000), 2)
        discount_amount = round(random.uniform(0, price * 0.5), 2)  # Discount up to 50% of price
        order_items.append((order_id, product_id, quantity, price, discount_amount))
    return order_items

def generate_orders(num_orders):
    orders = []
    existing_order_numbers = set()  # Use a set to track unique order numbers
    for i in range(1, num_orders + 1):
        while True:
            order_number = f"ORD-{random.randint(100000, 999999)}"  # Generate a random 6-digit order number
            if order_number not in existing_order_numbers:  # Ensure uniqueness
                existing_order_numbers.add(order_number)
                break
        user_id = random.randint(1, 100)  # Assuming 100 users exist
        customer_id = random.randint(1, 100)  # Assuming 100 customers exist
        order_date = fake.date_time_this_year()
        total_amount = round(random.uniform(50, 5000), 2)
        tax_amount = round(total_amount * 0.1, 2)  # 10% tax
        shipping_amount = round(random.uniform(5, 50), 2)
        payment_method = random.choice(['Cash', 'Credit Card', 'Debit Card', 'Bank Transfer', 'Other'])
        payment_status = random.choice(['Pending', 'Paid', 'Failed', 'Refunded'])
        status = random.choice(['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled', 'Refunded'])
        notes = fake.text(max_nb_chars=100)
        orders.append((user_id, customer_id, order_number, order_date, total_amount, tax_amount, shipping_amount, payment_method, payment_status, status, notes))
    return orders

def generate_stock_transactions(num_transactions):
    stock_transactions = []
    cursor.execute("SELECT user_id FROM Users")  # Fetch existing user IDs
    user_ids = [row[0] for row in cursor.fetchall()]
    cursor.execute("SELECT product_id FROM Products")  # Fetch existing product IDs
    product_ids = [row[0] for row in cursor.fetchall()]

    for i in range(1, num_transactions + 1):
        product_id = random.choice(product_ids)  # Use a valid product_id
        transaction_type = random.choice(['IN', 'OUT', 'ADJUSTMENT', 'RETURN'])
        quantity = random.randint(1, 100)
        reference_id = f"REF-{random.randint(1000, 9999)}"
        reference_type = random.choice(['ORDER', 'PURCHASE', 'ADJUSTMENT', 'OTHER'])
        notes = fake.text(max_nb_chars=100)
        transaction_date = fake.date_time_this_year()
        user_id = random.choice(user_ids)  # Use a valid user_id
        stock_transactions.append((product_id, transaction_type, quantity, reference_id, reference_type, notes, transaction_date, user_id))
    return stock_transactions

def generate_suppliers(num_suppliers):
    suppliers = []
    for i in range(1, num_suppliers + 1):
        name = fake.company()
        contact = fake.name()
        email = fake.email()
        phone = fake.msisdn()[:20]  # Truncate phone number to 20 characters
        address = fake.address()
        city = fake.city()
        country = fake.country()[:50]  # Truncate country to 50 characters
        postal_code = fake.postcode()
        suppliers.append((name, contact, email, phone, address, city, country, postal_code))
    return suppliers

def generate_users(num_users):
    users = []
    generated_usernames = set()  # Track unique usernames to avoid duplicates
    generated_emails = set()  # Track unique emails to avoid duplicates
    for i in range(1, num_users + 1):
        while True:
            username = fake.user_name()
            if username not in generated_usernames:  # Ensure unique username
                generated_usernames.add(username)
                break
        while True:
            email = fake.email()
            if email not in generated_emails:  # Ensure unique email
                generated_emails.add(email)
                break
        password = fake.password(length=10)  # Generate a random password
        role = random.choice(['admin', 'manager', 'staff'])  # Randomly assign a role
        created_at = fake.date_time_this_year()
        users.append((username, password, email, role, created_at))
    return users

# Insert data into the database
def insert_data(table, data, query):
    try:
        cursor.executemany(query, data)
        db.commit()
        print(f"Inserted {len(data)} records into {table}")
    except mysql.connector.Error as err:
        print(f"Error inserting into {table}: {err}")

# Main function
def main():
    # Test the database connection
    try:
        cursor.execute("SELECT DATABASE();")
        current_db = cursor.fetchone()
        print(f"Connected to database: {current_db[0]}")
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return

    # Generate and insert users
    print("Generating users...")
    users = generate_users(1000)  # Generate 1000 users
    print(f"Generated {len(users)} users")  # Verify the number of generated users
    user_query = """
        INSERT INTO Users (username, password, email, role, created_at)
        VALUES (%s, %s, %s, %s, %s)
    """
    insert_data("Users", users, user_query)

    # Generate and insert discounts
    print("Generating discounts...")
    discounts = generate_discounts(1000)
    discount_query = """
        INSERT INTO Discounts (product_id, discount_name, discount_percentage, start_date, end_date, is_active)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    insert_data("Discounts", discounts, discount_query)

    # Generate and insert order items
    print("Generating order items...")
    order_items = generate_order_items(50000)
    order_item_query = """
        INSERT INTO OrderItems (order_id, product_id, quantity, price, discount_amount)
        VALUES (%s, %s, %s, %s, %s)
    """
    insert_data("OrderItems", order_items, order_item_query)

    # Generate and insert orders
    print("Generating orders...")
    orders = generate_orders(100005)
    order_query = """
        INSERT INTO Orders (user_id, customer_id, order_number, order_date, total_amount, tax_amount, shipping_amount, payment_method, payment_status, status, notes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    insert_data("Orders", orders, order_query)

    # Generate and insert stock transactions
    print("Generating stock transactions...")
    stock_transactions = generate_stock_transactions(100005)
    stock_transaction_query = """
        INSERT INTO StockTransactions (product_id, transaction_type, quantity, reference_id, reference_type, notes, transaction_date, user_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    insert_data("StockTransactions", stock_transactions, stock_transaction_query)

    # Generate and insert suppliers
    print("Generating suppliers...")
    suppliers = generate_suppliers(1000)
    supplier_query = """
        INSERT INTO Suppliers (name, contact, email, phone, address, city, country, postal_code)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    insert_data("Suppliers", suppliers, supplier_query)

if __name__ == "__main__":
    main()