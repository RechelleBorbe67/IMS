USE inventorydb;

SELECT 
    c.category_name,
    SUM(d.discount_percentage) AS total_discount_percentage,
    COUNT(d.discount_id) AS total_discounts
FROM Discounts d
JOIN Products p ON d.product_id = p.product_id
JOIN Categories c ON p.category_id = c.category_id
WHERE d.is_active = 1
GROUP BY c.category_name
ORDER BY total_discount_percentage DESC
LIMIT 10;

EXPLAIN
SELECT 
    c.category_name,
    SUM(d.discount_percentage) AS total_discount_percentage,
    COUNT(d.discount_id) AS total_discounts
FROM Discounts d
JOIN Products p ON d.product_id = p.product_id
JOIN Categories c ON p.category_id = c.category_id
WHERE d.is_active = 1
GROUP BY c.category_name
ORDER BY total_discount_percentage DESC
LIMIT 10;