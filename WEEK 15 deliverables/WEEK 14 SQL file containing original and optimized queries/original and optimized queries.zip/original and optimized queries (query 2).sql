USE inventorydb;

-- Query 2: Customer Lifetime Value Analysis
SELECT 
    c.customer_id,
    c.name,
    c.city,
    c.loyalty_points,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(o.total_amount) AS total_spent,
    AVG(o.total_amount) AS avg_order_value,
    DATEDIFF(CURRENT_DATE, MIN(o.order_date)) AS days_as_customer,
SUM(o.total_amount) / (DATEDIFF(CURRENT_DATE, MIN(o.order_date)) / 365) AS clv
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id
WHERE o.status NOT IN ('Cancelled', 'Refunded')
GROUP BY c.customer_id, c.name, c.city, c.loyalty_points
HAVING COUNT(DISTINCT o.order_id) > 1
ORDER BY clv DESC
LIMIT 100;



EXPLAIN
SELECT 
    c.customer_id,
    c.name,
    c.city,
    c.loyalty_points,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(o.total_amount) AS total_spent,
    AVG(o.total_amount) AS avg_order_value,
    DATEDIFF(CURRENT_DATE, MIN(o.order_date)) AS days_as_customer,
    SUM(o.total_amount) / (DATEDIFF(CURRENT_DATE, MIN(o.order_date)) / 365) AS clv
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id
WHERE o.status NOT IN ('Cancelled', 'Refunded')
GROUP BY c.customer_id, c.name, c.city, c.loyalty_points
HAVING COUNT(DISTINCT o.order_id) > 1
ORDER BY clv DESC
LIMIT 100;
