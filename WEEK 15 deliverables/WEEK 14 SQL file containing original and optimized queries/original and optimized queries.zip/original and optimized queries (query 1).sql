USE inventorydb;

-- Query 1: Monthly Sales Revenue by Product Category
SELECT 
    YEAR(o.order_date) AS year,
    MONTH(o.order_date) AS month,
    c.category_name,
    SUM(oi.total_price) AS total_sales,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(oi.quantity) AS units_sold
FROM Orders o
JOIN OrderItems oi ON o.order_id = oi.order_id
JOIN Products p ON oi.product_id = p.product_id
JOIN Categories c ON p.category_id = c.category_id
WHERE o.status NOT IN ('Cancelled', 'Refunded')
GROUP BY YEAR(o.order_date), MONTH(o.order_date), c.category_name
ORDER BY year, month, total_sales DESC;

EXPLAIN
SELECT 
    YEAR(o.order_date) AS year,
    MONTH(o.order_date) AS month,
    c.category_name,
    SUM(oi.total_price) AS total_sales,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(oi.quantity) AS units_sold
FROM Orders o
JOIN OrderItems oi ON o.order_id = oi.order_id
JOIN Products p ON oi.product_id = p.product_id
JOIN Categories c ON p.category_id = c.category_id
WHERE o.status NOT IN ('Cancelled', 'Refunded')
GROUP BY YEAR(o.order_date), MONTH(o.order_date), c.category_name
ORDER BY year, month, total_sales DESC;